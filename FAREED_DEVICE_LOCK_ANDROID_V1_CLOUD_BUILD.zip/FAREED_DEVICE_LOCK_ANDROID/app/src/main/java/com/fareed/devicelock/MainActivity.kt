package com.fareed.devicelock

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.fareed.devicelock.admin.KioskAdminReceiver

class MainActivity : Activity() {

    private lateinit var dpm: DevicePolicyManager
    private lateinit var admin: ComponentName
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        admin = ComponentName(this, KioskAdminReceiver::class.java)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            setBackgroundColor(0xFF101820.toInt())
        }

        val title = TextView(this).apply {
            text = "FAREED DEVICE LOCK"
            textSize = 26f
            setTextColor(0xFF00DDAA.toInt())
        }

        status = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 28, 0, 28)
        }

        val startButton = Button(this).apply {
            text = "إعداد وبدء وضع Kiosk"
            setOnClickListener { startKiosk() }
        }

        val stopButton = Button(this).apply {
            text = "إيقاف وضع Kiosk (للمسؤول)"
            setOnClickListener { requestAdminPinAndStop() }
        }

        val info = TextView(this).apply {
            text = "يعمل القفل الإداري فقط بعد تسجيل هذا التطبيق Device Owner على جهاز تملكه أو تديره بتصريح. لا يحاول التطبيق تجاوز حماية Android."
            textSize = 14f
            setTextColor(0xFFDDDDDD.toInt())
            setPadding(0, 28, 0, 0)
        }

        layout.addView(title)
        layout.addView(status)
        layout.addView(startButton)
        layout.addView(stopButton)
        layout.addView(info)
        setContentView(layout)
        refreshStatus()
    }

    private fun refreshStatus() {
        val isOwner = dpm.isDeviceOwnerApp(packageName)
        val isAdmin = dpm.isAdminActive(admin)
        status.text = "Device Owner: ${if (isOwner) "نعم" else "لا"}\nDevice Admin: ${if (isAdmin) "مفعّل" else "غير مفعّل"}\nLock Task permitted: ${dpm.isLockTaskPermitted(packageName)}"
    }

    private fun startKiosk() {
        if (!dpm.isDeviceOwnerApp(packageName)) {
            Toast.makeText(
                this,
                "يلزم إعداد التطبيق Device Owner أولاً. راجع دليل Android في المشروع.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        try {
            // السماح لهذا التطبيق وحده باستخدام Lock Task Mode.
            dpm.setLockTaskPackages(admin, arrayOf(packageName))
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                dpm.setLockTaskFeatures(
                    admin,
                    DevicePolicyManager.LOCK_TASK_FEATURE_NONE
                )
            }
            startLockTask()
            refreshStatus()
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر بدء Kiosk: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestAdminPinAndStop() {
        val input = android.widget.EditText(this).apply {
            hint = "رمز المسؤول التجريبي"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }

        AlertDialog.Builder(this)
            .setTitle("تأكيد المسؤول")
            .setMessage("أدخل الرمز التجريبي 1212 لإيقاف الجلسة.")
            .setView(input)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("إيقاف") { _, _ ->
                if (input.text.toString() == "1212") {
                    try {
                        stopLockTask()
                        Toast.makeText(this, "تم طلب إيقاف وضع Kiosk", Toast.LENGTH_SHORT).show()
                    } catch (_: Exception) {
                        Toast.makeText(this, "التطبيق ليس في وضع Kiosk حاليًا", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "رمز غير صحيح", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
    }
}
