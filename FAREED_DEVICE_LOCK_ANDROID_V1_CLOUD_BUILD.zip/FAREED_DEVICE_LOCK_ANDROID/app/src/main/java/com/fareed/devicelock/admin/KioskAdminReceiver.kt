package com.fareed.devicelock.admin

import android.app.admin.DeviceAdminReceiver

class KioskAdminReceiver : DeviceAdminReceiver()
